# real_estate_pricing_model
A Kaggle machine learning project to estimate real estate prices in Ames, IA
